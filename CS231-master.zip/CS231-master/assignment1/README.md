Details about this assignment can be found [on the course webpage](https://cs231n.github.io/assignment1/).
