# CS231n: Convolutional Neural Networks for Visual Recognition

These  past  weeks,  I  have  been following  the  Stanford  CS  class
[CS231n: Convolutional Neural Networks for Visual Recognition](http://cs231n.github.io/). You
can find my solutions to the assignment in this repo.

I also wrote two blog posts related to this resolution. 

-  One  on  the  implementation   of  batch-norm  that  you  can  find
  [here](http://cthorey.github.io./backpropagation/).
- Another on the implementation of a conv-net that you can find [here](http://cthorey.github.io./backprop_conv/).

A big thank  to all the team  from the CS231 Stanford class  who do a
fantastic work in vulgarizing the knowledge behind neural networks.
